package com.example.lfsr_otp_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
