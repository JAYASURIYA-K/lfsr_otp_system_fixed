import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const LFSROTPApp());
}

class LFSROTPApp extends StatelessWidget {
  const LFSROTPApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LFSR OTP System',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF00E5FF),
          secondary: Color(0xFF1DE9B6),
          surface: Color(0xFF1A1A2E),
          background: Color(0xFF0D0D1A),
          error: Color(0xFFFF5252),
          onPrimary: Color(0xFF000000),
          onSecondary: Color(0xFF000000),
          onSurface: Color(0xFFE0E0E0),
          onBackground: Color(0xFFE0E0E0),
          onError: Color(0xFFFFFFFF),
        ),
        useMaterial3: true,
        fontFamily: 'RobotoMono',
      ),
      home: const OTPScreen(),
    );
  }
}

class OTPResponse {
  final String otp;
  final String device;

  OTPResponse({required this.otp, required this.device});

  factory OTPResponse.fromJson(Map<String, dynamic> json) {
    return OTPResponse(
      otp: json['otp']?.toString() ?? '',
      device: json['device']?.toString() ?? '',
    );
  }
}

class OTPScreen extends StatefulWidget {
  const OTPScreen({super.key});

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> with TickerProviderStateMixin {
  static const String _baseUrl = 'http://192.168.4.1';
  static const int _otpDuration = 30;
  static const String _deviceIdKey = 'device_id';

  String _deviceId = '';
  String _otp = '';
  String _statusMessage = 'Press GET OTP to retrieve your one-time password';
  bool _isLoading = false;
  bool _isExpired = false;
  bool _hasOtp = false;
  int _remainingSeconds = _otpDuration;

  Timer? _countdownTimer;
  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _loadOrCreateDeviceId();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
  }

  Future<void> _loadOrCreateDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    String? existingId = prefs.getString(_deviceIdKey);
    if (existingId == null || existingId.isEmpty) {
      final uuid = const Uuid().v4().replaceAll('-', '').toUpperCase();
      existingId = 'DEV_${uuid.substring(0, 8)}';
      await prefs.setString(_deviceIdKey, existingId);
    }
    setState(() {
      _deviceId = existingId!;
    });
  }

  void _startCountdown() {
    _countdownTimer?.cancel();
    setState(() {
      _remainingSeconds = _otpDuration;
      _isExpired = false;
    });

    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_remainingSeconds > 0) {
          _remainingSeconds--;
        } else {
          _isExpired = true;
          _hasOtp = false;
          _statusMessage = 'OTP expired. Request a new one.';
          timer.cancel();
          _pulseController.stop();
        }
      });
    });
  }

  Future<void> _getOtp() async {
    if (_deviceId.isEmpty) return;
    await _requestOtp(endpoint: '/getotp');
  }

  Future<void> _resendOtp() async {
    if (_deviceId.isEmpty) return;
    await _requestOtp(endpoint: '/resend');
  }

  Future<void> _requestOtp({required String endpoint}) async {
    setState(() {
      _isLoading = true;
      _statusMessage = 'Connecting to ESP8266...';
    });

    try {
      final uri = Uri.parse('$_baseUrl$endpoint?device=$_deviceId');
      final response = await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> json = jsonDecode(response.body);
        final otpResponse = OTPResponse.fromJson(json);

        if (otpResponse.otp.isEmpty) {
          throw Exception('Invalid OTP received from server');
        }

        setState(() {
          _otp = otpResponse.otp;
          _hasOtp = true;
          _isExpired = false;
          _statusMessage = 'OTP received successfully';
        });

        _fadeController.reset();
        _fadeController.forward();

        if (!_pulseController.isAnimating) {
          _pulseController.repeat(reverse: true);
        }

        _startCountdown();
      } else {
        setState(() {
          _statusMessage = 'Server error: HTTP ${response.statusCode}';
          _hasOtp = false;
        });
      }
    } on TimeoutException {
      setState(() {
        _statusMessage = 'Connection timeout. Is ESP8266 active?';
        _hasOtp = false;
      });
    } on http.ClientException catch (e) {
      setState(() {
        _statusMessage = 'Connection failed: ${e.message}';
        _hasOtp = false;
      });
    } on FormatException {
      setState(() {
        _statusMessage = 'Invalid response format from server';
        _hasOtp = false;
      });
    } catch (e) {
      setState(() {
        _statusMessage = 'Error: ${e.toString()}';
        _hasOtp = false;
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Color _getTimerColor() {
    if (_remainingSeconds > 15) return const Color(0xFF1DE9B6);
    if (_remainingSeconds > 5) return const Color(0xFFFFD740);
    return const Color(0xFFFF5252);
  }

  double _getTimerProgress() {
    return _remainingSeconds / _otpDuration;
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _pulseController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1A),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              _buildDeviceCard(),
              const SizedBox(height: 24),
              _buildOtpCard(),
              const SizedBox(height: 24),
              _buildTimerCard(),
              const SizedBox(height: 24),
              _buildStatusCard(),
              const SizedBox(height: 32),
              _buildGetOtpButton(),
              const SizedBox(height: 16),
              _buildResendButton(),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        const SizedBox(height: 8),
        Container(
          width: 64,
          height: 64,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFF00E5FF), Color(0xFF1DE9B6)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00E5FF).withOpacity(0.4),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Icon(Icons.lock_outline, color: Colors.black, size: 32),
        ),
        const SizedBox(height: 16),
        const Text(
          'LFSR OTP SYSTEM',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF00E5FF),
            letterSpacing: 4,
          ),
        ),
        const SizedBox(height: 4),
        const Text(
          'ESP8266 One-Time Password',
          style: TextStyle(
            fontSize: 13,
            color: Color(0xFF607D8B),
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }

  Widget _buildDeviceCard() {
    return _buildCard(
      child: Row(
        children: [
          const Icon(Icons.devices, color: Color(0xFF00E5FF), size: 20),
          const SizedBox(width: 12),
          const Text(
            'DEVICE ID',
            style: TextStyle(
              fontSize: 11,
              color: Color(0xFF607D8B),
              letterSpacing: 2,
            ),
          ),
          const Spacer(),
          Text(
            _deviceId.isEmpty ? 'Loading...' : _deviceId,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: Color(0xFF00E5FF),
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOtpCard() {
    return _buildCard(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.password, color: Color(0xFF607D8B), size: 16),
              const SizedBox(width: 8),
              const Text(
                'ONE-TIME PASSWORD',
                style: TextStyle(
                  fontSize: 11,
                  color: Color(0xFF607D8B),
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          if (_hasOtp && !_isExpired)
            FadeTransition(
              opacity: _fadeAnimation,
              child: ScaleTransition(
                scale: _pulseAnimation,
                child: _buildOtpDisplay(),
              ),
            )
          else if (_isExpired)
            _buildExpiredDisplay()
          else
            _buildPlaceholderDisplay(),
        ],
      ),
    );
  }

  Widget _buildOtpDisplay() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: _otp.split('').asMap().entries.map((entry) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: 42,
          height: 54,
          decoration: BoxDecoration(
            color: const Color(0xFF00E5FF).withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: const Color(0xFF00E5FF).withOpacity(0.5),
              width: 1.5,
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            entry.value,
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Color(0xFF00E5FF),
              letterSpacing: 0,
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildExpiredDisplay() {
    return Column(
      children: [
        const Icon(Icons.timer_off_outlined, color: Color(0xFFFF5252), size: 40),
        const SizedBox(height: 8),
        const Text(
          'OTP EXPIRED',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFFFF5252),
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }

  Widget _buildPlaceholderDisplay() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(6, (index) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          width: 42,
          height: 54,
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A2E),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: const Color(0xFF263238),
              width: 1.5,
            ),
          ),
          alignment: Alignment.center,
          child: const Text(
            '—',
            style: TextStyle(
              fontSize: 20,
              color: Color(0xFF37474F),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildTimerCard() {
    if (!_hasOtp && !_isExpired) return const SizedBox.shrink();

    final timerColor = _getTimerColor();
    final progress = _getTimerProgress();

    return _buildCard(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.timer_outlined, color: timerColor, size: 16),
                  const SizedBox(width: 8),
                  const Text(
                    'EXPIRES IN',
                    style: TextStyle(
                      fontSize: 11,
                      color: Color(0xFF607D8B),
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
              Text(
                _isExpired ? '0s' : '${_remainingSeconds}s',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: timerColor,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: _isExpired ? 0 : progress,
              backgroundColor: const Color(0xFF263238),
              valueColor: AlwaysStoppedAnimation<Color>(timerColor),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusCard() {
    return _buildCard(
      child: Row(
        children: [
          Icon(
            _isLoading
                ? Icons.sync
                : _hasOtp && !_isExpired
                    ? Icons.check_circle_outline
                    : _isExpired
                        ? Icons.error_outline
                        : Icons.info_outline,
            color: _isLoading
                ? const Color(0xFF00E5FF)
                : _hasOtp && !_isExpired
                    ? const Color(0xFF1DE9B6)
                    : _isExpired
                        ? const Color(0xFFFF5252)
                        : const Color(0xFF607D8B),
            size: 18,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              _statusMessage,
              style: const TextStyle(
                fontSize: 13,
                color: Color(0xFFB0BEC5),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGetOtpButton() {
    return SizedBox(
      height: 56,
      child: ElevatedButton(
        onPressed: _isLoading ? null : _getOtp,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF00E5FF),
          foregroundColor: Colors.black,
          disabledBackgroundColor: const Color(0xFF263238),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          elevation: 0,
        ),
        child: _isLoading
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: Colors.black54,
                ),
              )
            : const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.vpn_key_outlined, size: 20),
                  SizedBox(width: 10),
                  Text(
                    'GET OTP',
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildResendButton() {
    return SizedBox(
      height: 56,
      child: OutlinedButton(
        onPressed: _isLoading ? null : _resendOtp,
        style: OutlinedButton.styleFrom(
          foregroundColor: const Color(0xFF1DE9B6),
          side: BorderSide(
            color: _isLoading
                ? const Color(0xFF263238)
                : const Color(0xFF1DE9B6).withOpacity(0.6),
            width: 1.5,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.refresh_outlined, size: 20),
            SizedBox(width: 10),
            Text(
              'RESEND OTP',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: const Color(0xFF263238),
          width: 1,
        ),
      ),
      child: child,
    );
  }
}
