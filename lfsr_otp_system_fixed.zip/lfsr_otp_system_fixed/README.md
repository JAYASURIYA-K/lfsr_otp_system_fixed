# LFSR OTP System — Flutter Android App

A Flutter Android app that connects to an ESP8266 Access Point and retrieves 6-digit OTPs via HTTP.

---

## Prerequisites

- Flutter 3.10+ (tested with 3.44+)
- Android Studio (latest)
- Android SDK 36
- NDK 27.0.12077973

---

## Setup Instructions

### 1. Set local.properties

Open `android/local.properties` and update:

```
flutter.sdk=/path/to/your/flutter/sdk
sdk.dir=/path/to/your/android/sdk
```

Android Studio usually sets these automatically when you open the project.

### 2. Install Dependencies

```bash
flutter pub get
```

### 3. Build APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk`

---

## ESP8266 Connection

- ESP8266 must be broadcasting its Wi-Fi Access Point
- Connect your Android device to the ESP8266 Wi-Fi network
- The app connects to: `http://192.168.4.1`

### Endpoints Used

| Endpoint | Description |
|---|---|
| `GET /getotp?device=<deviceId>` | Request a new OTP |
| `GET /resend?device=<deviceId>` | Resend the last OTP |

### Expected JSON Response

```json
{
  "otp": "123456",
  "device": "DEVICE_001"
}
```

---

## Features

- Unique device ID generated once on first launch (persists across sessions)
- GET OTP and RESEND OTP buttons
- 6-digit OTP displayed in individual digit boxes
- 30-second countdown timer with color feedback (green → yellow → red)
- OTP Expired state when timer reaches 0
- Connection error handling with descriptive messages
- Dark theme with cyan/teal accent colors
- No login required

---

## Project Structure

```
lfsr_otp_system/
├── lib/
│   └── main.dart              # Full app code
├── android/
│   ├── app/
│   │   ├── build.gradle.kts
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/com/example/lfsr_otp_system/
│   │       │   └── MainActivity.kt
│   │       └── res/
│   │           ├── mipmap-*/ic_launcher.png
│   │           └── values/styles.xml
│   ├── build.gradle.kts
│   ├── settings.gradle.kts
│   ├── gradle.properties
│   └── gradle/wrapper/gradle-wrapper.properties
├── pubspec.yaml
└── analysis_options.yaml
```
